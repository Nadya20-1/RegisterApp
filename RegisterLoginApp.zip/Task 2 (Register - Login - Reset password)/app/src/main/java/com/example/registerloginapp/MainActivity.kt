package com.example.registerloginapp

import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.fragment_login.*
import kotlinx.android.synthetic.main.fragment_register.*
import kotlinx.android.synthetic.main.fragment_resetpassword.*
import java.util.*
import java.util.regex.Pattern


class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        supportFragmentManager
        if (savedInstanceState == null) {
            supportFragmentManager
                    .beginTransaction()
                    .replace(R.id.frameContainer, LoginFragment(),
                            Utils.LoginFragment).commit()
        }
        button_rus.setOnClickListener {
            recreate()
            setAppLocale(Locale.forLanguageTag("Ru"))
        }
        button_eng.setOnClickListener {
            recreate()
            setAppLocale(Locale.ENGLISH)
        }
    }

    private fun replaceLoginFragment() {
        supportFragmentManager
                .beginTransaction()
                .replace(R.id.frameContainer, LoginFragment(),
                        Utils.LoginFragment).commit()
    }

    private fun replaceRegisterFragment() {
        supportFragmentManager
                .beginTransaction()
                .replace(R.id.frameContainer, RegisterFragment(),
                        Utils.RegisterFragment).commit()
    }

    private fun replaceResetPasswordFragment() {
        supportFragmentManager
                .beginTransaction()
                .replace(R.id.frameContainer, ResetPasswordFragment(),
                        Utils.ResetPasswordFragment).commit()
    }

    override fun onBackPressed() {
        val signUpFragment = supportFragmentManager
                .findFragmentByTag(Utils.RegisterFragment)
        val forgotPasswordFragment = supportFragmentManager
                .findFragmentByTag(Utils.ResetPasswordFragment)
        if (signUpFragment != null) replaceLoginFragment() else if (forgotPasswordFragment != null) replaceRegisterFragment() else super.onBackPressed()
    }

    @Suppress("DEPRECATION")
    private fun setAppLocale(localeCode: Locale) {
        val res = resources
        val dm = res.displayMetrics
        val conf = res.configuration
        if (Build.VERSION.SDK_INT >= 23) {
            conf.setLocale(Locale(localeCode.toString()))
        } else {
            conf.locale = Locale(localeCode.toString())
        }
        res.updateConfiguration(conf, dm)
    }

    fun onClick(vr: View) {
        when (vr.id) {
            //Login
            R.id.login_button -> if (checkValidationLogin()) {
              replaceLoginFragment()
            }
            R.id.login_forget_password -> replaceResetPasswordFragment()
            R.id.login_any_account -> replaceRegisterFragment()
            //Register
            R.id.register_button -> if (checkValidationRegister()) {
                replaceLoginFragment()
                val emailr = register_email.text.toString()
                val bundle = Bundle()
                bundle.putString("Email", emailr)
                val fragmentManager = supportFragmentManager
                val fragmentTransaction = fragmentManager.beginTransaction()
                val loginFragment = LoginFragment()
                loginFragment.arguments = bundle
                fragmentTransaction.replace(R.id.frameContainer, loginFragment)
                fragmentTransaction.commit()
            }
            R.id.register_any_account -> replaceLoginFragment()
            //ResetPassword
            R.id.confirm_button -> if (checkValidationResetPassword()) replaceLoginFragment()
            R.id.confirm_any_account -> replaceRegisterFragment()
        }
    }

    private fun checkValidationLogin(): Boolean {
        var valid = true
        val getEmailId = login_email.text.toString()
        val getPassword = login_password.text.toString()
        val p = Pattern.compile(Utils.regEx)
        val m = p.matcher(getEmailId)
        if (getEmailId == "" || getEmailId.isEmpty() || getPassword == ""  || getPassword.isEmpty()) {
            login_email_input.error = getText(R.string.error_field_required)
            login_password_input.error = getText(R.string.error_field_required)
            valid = false
        } else if (!m.find() || getPassword.length < 6 ) {
            login_email_input.error = getText(R.string.error_email)
            login_password_input.error = getText(R.string.error_password)
            valid = false
        }  else Toast.makeText(this, R.string.login_text, Toast.LENGTH_SHORT)
                .show()
        return valid
    }

    private fun checkValidationRegister(): Boolean {
        var valid = true
        val getFullName = register_name.text.toString()
        val getEmailId = register_email.text.toString()
        val getMobileNumber = register_number.text.toString()
        val getPassword = register_password.text.toString()
        val p = Pattern.compile(Utils.regEx)
        val m = p.matcher(getEmailId)
        if (getFullName == "" || getFullName.isEmpty() || getEmailId == "" || getEmailId.isEmpty() || getMobileNumber == "" || getMobileNumber.isEmpty() || getPassword == "" || getPassword.isEmpty()) {
            register_email_input.error = getText(R.string.error_field_required)
            register_username_input.error = getText(R.string.error_field_required)
            register_password_input.error = getText(R.string.error_field_required)
            register_number_input.error = getText(R.string.error_field_required)
            valid = false
        } else if (!m.find() || getPassword.length < 6) {
            register_email_input.error = getText(R.string.error_email)
            register_password_input.error = getText(R.string.error_password)
            valid = false
        } else Toast.makeText(this, R.string.register_text, Toast.LENGTH_SHORT)
                .show()
        return valid
    }

    private fun checkValidationResetPassword(): Boolean {
        var valid = true
        val getConfirmPassword = confirm_reset_password.text.toString()
        val getEmailId =  confirm_email.text.toString()
        val getPassword = confirm_password.text.toString()
        val p = Pattern.compile(Utils.regEx)
        val m = p.matcher(getEmailId)
        if (getEmailId == "" || getEmailId.isEmpty() || getPassword == "" || getPassword.isEmpty() || getConfirmPassword == "" || getConfirmPassword.isEmpty()) {
            reset_email_input.error = getText(R.string.error_field_required)
            reset_password_input.error = getText(R.string.error_field_required)
            reset_confirm_input.error = getText(R.string.error_field_required)
            valid = false
        } else if (!m.find() || getConfirmPassword.length < 6 || getPassword.length < 6) {
            reset_email_input.error = getText(R.string.error_email)
            reset_password_input.error = getText(R.string.error_password)
            reset_confirm_input.error = getText(R.string.error_password)
            valid = false
        } else if (getConfirmPassword != getPassword) {
            reset_confirm_input.error = getText(R.string.error_reset)
            reset_password_input.error = getText(R.string.error_reset)
            valid = false
        } else Toast.makeText(this, R.string.reset_text, Toast.LENGTH_SHORT)
                .show()
        return valid
    }

    override fun recreate() {
        val intent = intent
        finish()
        startActivity(intent)
        super.recreate()
    }
}